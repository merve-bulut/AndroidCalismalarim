package com.example.userinputshow;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public String isaretliler="isaretli: ";
    private CheckBox cb1;
    private CheckBox cb2;
    private CheckBox cb3;
    private CheckBox cb4;
    private CheckBox cb5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cb1 = findViewById(R.id.cbOne);
        cb2 = findViewById(R.id.cbTwo);
        cb3 = findViewById(R.id.cbThree);
        cb4 = findViewById(R.id.cbFour);
        cb5 = findViewById(R.id.cbFive);

        cb1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(cb1.isChecked())
                    Toast.makeText(getApplicationContext(), buttonView.getText(), Toast.LENGTH_SHORT).show();
            }
        });
        cb2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(cb2.isChecked())
                    Toast.makeText(getApplicationContext(), buttonView.getText(), Toast.LENGTH_SHORT).show();
            }
        });
        cb3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(cb3.isChecked())
                    Toast.makeText(getApplicationContext(), buttonView.getText(), Toast.LENGTH_SHORT).show();
            }
        });
        cb4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(cb4.isChecked())
                    Toast.makeText(getApplicationContext(), buttonView.getText(), Toast.LENGTH_SHORT).show();
            }
        });
        cb5.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(cb5.isChecked())
                    Toast.makeText(getApplicationContext(), buttonView.getText(), Toast.LENGTH_SHORT).show();
            }
        });

        Button b = findViewById(R.id.bShow);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(cb1.isChecked())
                    isaretliler += " "+cb1.getText();
                if(cb2.isChecked())
                    isaretliler += " "+cb2.getText();
                if(cb3.isChecked())
                    isaretliler += " "+cb3.getText();
                if(cb4.isChecked())
                    isaretliler += " "+cb4.getText();
                if(cb5.isChecked())
                    isaretliler += " "+cb5.getText();
                Toast.makeText(getApplicationContext(), isaretliler, Toast.LENGTH_LONG).show();
            }
        });

    }
    //Question 1
    //What's the most important difference between checkboxes and a RadioGroup of radio buttons? Choose one:
    //The only differences is how they appear: checkboxes show a checkmark when selected, while circular "radio" buttons
    //appear filled when selected.
    //CheckBox elements in the layout can use the android:onClick attribute to call a handler when selected.
    //The major difference is that checkboxes enable multiple selections, while a RadioGroup allows only one selection.
    //Answer 1
    //The major difference is that checkboxes enable multiple selections, while a RadioGroup allows only one selection.

    //Question 2
    //Which layout group is the preferred way to align a set of CheckBox elements vertically? Choose one:
    //RelativeLayout
    //LinearLayout
    //ScrollView
    //Answer2
    //LinearLayout

    //Question 3
    //What method of the Checkable interface do you use to check the state of a checkbox (that is, whether it has been checked
    //or not)?
    //Answer 3
    //isChecked()
}

