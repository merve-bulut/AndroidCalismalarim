package com.example.userinputshow;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btn;
    CheckBox cbOne, cbTwo, cbThree, cbFour, cbFive;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
        setClickables();
    }

    public void initViews(){ //activity_main.xml sayfasında oluşturduğum nesnelere erişip yukarıda tanımladığım değişkenlere bağladım.
        cbOne = (CheckBox) findViewById(R.id.cbOpOne);
        cbTwo = (CheckBox) findViewById(R.id.cbOpTwo);
        cbThree = (CheckBox) findViewById(R.id.cbOpThree);
        cbFour = (CheckBox) findViewById(R.id.cbOpFour);
        cbFive = (CheckBox) findViewById(R.id.cbOpFive);
        btn = (Button) findViewById(R.id.bShow);
    }

    public void setClickables(){
        if(cbOne.isChecked()){
            Toast.makeText(getApplicationContext(), btn.getText(), Toast.LENGTH_SHORT).show();
        }
        if(cbTwo.isChecked()){
            Toast.makeText(getApplicationContext(), btn.getText(), Toast.LENGTH_SHORT).show();
        }
        if(cbThree.isChecked()){
            Toast.makeText(getApplicationContext(), btn.getText(), Toast.LENGTH_SHORT).show();
        }
        if(cbFour.isChecked()){
            Toast.makeText(getApplicationContext(), btn.getText(), Toast.LENGTH_SHORT).show();
        }
        if(cbFive.isChecked()){
            Toast.makeText(getApplicationContext(), btn.getText(), Toast.LENGTH_SHORT).show();
        }
    }

    /*Question 1
    *What's the most important difference between checkboxes and a RadioGroup of radio buttons?
    * Answer 1
    *The major difference is that checkboxes enable multiple selections, while a RadioGroup allows only one selection.
    * Question 2
    *Which layout group is the preferred way to align a set of CheckBox elements vertically?
    * Answer 2
    *LinearLayout
    * Question 3
    * What method of the Checkable interface do you use to check the state of a checkbox (that is, whether it has been checked
    * or not)?
    * Answer 3
    * isChecked()
    */
}


