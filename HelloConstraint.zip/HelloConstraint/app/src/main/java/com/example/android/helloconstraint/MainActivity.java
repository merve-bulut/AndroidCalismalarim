/*
 * Copyright (C) 2016 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.android.helloconstraint;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Displays two buttons and a text view.
 * - Pressing the TOAST button shows a toast.
 * - Pressing the COUNT button increases the displayed mCount.
 * <p>
 * Note: Fixing behavior when device is rotated is a challenge exercise for the student.
 */

public class MainActivity extends AppCompatActivity {

    private int mCount = 0;
    private int zero = 0;
    private TextView mShowCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mShowCount = (TextView) findViewById(R.id.show_count);
    }

    /**
     * Increments the number in the text view when the COUNT button is clicked.
     *
     * @param view The view that triggered this onClick handler.
     *             Since the count always appears in the text view, the passed in view is not used.
     */
    public void countUp(View view) {

        mCount++;
        if (mShowCount != null){
            mShowCount.setText(Integer.toString(mCount));
        }

        Button btn = (Button) view.findViewById(R.id.button_count);
        Button btnZero = (Button) findViewById(R.id.button_zero);

        if(mCount%2 == 0){
            btn.setBackgroundColor(Color.GREEN);
            btnZero.setBackgroundColor(Color.BLACK);

        }
        else if (mCount%2 == 1){
            btn.setBackgroundColor(Color.YELLOW);
            btnZero.setBackgroundColor(Color.BLACK);
        }

    }

    /**
     * Shows a toast when the TOAST button is clicked.
     *
     * @param view The view that triggered this onClick handler.
     *             Since a toast always shows on the top, the passed in view is not used.
     */
    public void showToast(View view) {
        int duration = Toast.LENGTH_LONG;

        Toast toast = Toast.makeText(this, R.string.toast_button_toast, duration);
        toast.show();
    }

    public void reset(View view){
        mShowCount.setText(Integer.toString(zero));
        mCount = 0;
        Button btnZero = (Button) findViewById(R.id.button_zero);
        btnZero.setBackgroundColor(Color.GRAY);
    }

    //Question 1
    //What are the layout constraint attributes on the Zero button to position it vertically equal distance between the other two
    //buttons?
    //Answer 1
    //app:layout_constraintBottom_toTopOf="@+id/button_count"
    //app:layout_constraintTop_toBottomOf="@+id/button_toast"

    //Question 2
    //What is the layout constraint attribute on the Zero button to position it horizontally in alignment with the other two buttons?
    //Answer 2
    //app:layout_constraintEnd_toStartOf="@+id/show_count"
    //app:layout_constraintStart_toStartOf="parent"

    //Question 3
    //Which of the following operations can you perform to include the Zero button in the xlarge (tablet) and land (landscape)
    //layouts that have already been created?
    //Answer 3
    //Bilgisayarım emülatörü çalıştırmadığından tablet seçeneklerini uygulayamadım.

    //Question 4
    //What is the correct signature for a method used as the value of the android:onClick XML attribute?
    //public void callMethod()
    //public void callMethod(View view)
    //private void callMethod(View view)
    //public boolean callMethod(View view)
    //Answer 4
    //public void callMethod(View view)

    //Question 5
    //The click handler for the Count button starts with the following method signature:
    //public void countUp(View view)
    //Which of the following techniques is more efficient to use within this handler to change the button's background color?
    //Choose one:
    //Use findViewById to find the Count button view. Assign the result to a View variable, and then use
    //setBackgroundColor().
    //Use the view parameter that is passed to the click handler with setBackgroundColor().
    //Answer 5
    //Use the view parameter that is passed to the click handler with setBackgroundColor().

}
