/*
 * Copyright (C) 2016 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.android.scrollingtext;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.view.ContextMenu;
import android.widget.ScrollView;
import android.widget.Toast;

/**
 * This app displays a scrollable TextView (a magazine article).
 * All changes were made to the layout. No code changes.
 * The code below is part of the Empty Activity template.
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ScrollView scrollView = findViewById(R.id.scrollView);
        registerForContextMenu(scrollView);
    }

    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo){
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
    }

    public boolean onContextItemSelected(MenuItem item){
        if(item.getItemId()==R.id.edit){
            Toast.makeText(getApplicationContext(),"edit",Toast.LENGTH_LONG).show();
        }else if(item.getItemId()==R.id.delete){
            Toast.makeText(getApplicationContext(),"delete",Toast.LENGTH_LONG).show();
        }else if(item.getItemId()==R.id.share){
            Toast.makeText(getApplicationContext(),"share",Toast.LENGTH_LONG).show();
        }else{
            return false;
        }
        return true;
    }

    //Question 1
    //What is the name and location of the file in which you create context menu items?
    //Answer 1
    //menu, app.src.main.res.menu.menu.xml

    //Question 2
    //What happens when a long tap (also known as a long click) occurs? Choose one:
    //When a view receives a long-click event, the system calls the onCreateContextMenu() method, which you can't
    //change.
    //When a registered view receives a long-click event, the system calls the onCreateContextMenu() method, which you
    //can override in your activity or fragment.
    //When a registered view receives a long-click event, the system calls the onContextItemSelected() method, which you
    //can override in your activity or fragment.
    //Answer 2
    //When a registered view receives a long-click event, the system calls the onContextItemSelected() method, which you
    //can override in your activity or fragment.

    //Question 3
    //Where do you register a context menu for a view? Choose one:
    //Use registerForContextMenu() in the onCreate() method.
    //Use registerForContextMenu() in the onCreateContextMenu() method.
    //Use getMenuInflater() in the onCreateContextMenu() method.
    //Answer 3
    //Use registerForContextMenu() in the onCreate() method.

    //Question 4
    //Where do you inflate the context menu using MenuInflater? Choose one:
    //In the onCreate() method.
    //In the onCreateContextMenu() method.
    //In the onContextItemSelected() method.
    //Answer 4
    //In the onCreateContextMenu() method.
}
